---
title: Kontakt
menu: Kontakt
slug: kontakt
---

## Kontakt aufnehmen

Joachim Richter  
Joachim Richter GmbH  
Vieristrasse 1  
8603 Schwerzenbach  
Schweiz  

📞 +41 79 415 24 16  
📧 [joachim.richter@jr-gmbh.ch](mailto:joachim.richter@jr-gmbh.ch)  
🔗 [LinkedIn](https://linkedin.com/in/joachim-richter-846609)

---

## Impressum

**Joachim Richter GmbH**  
CHE-138.704.920  
Gesellschaft mit beschränkter Haftung  
Vertretungsberechtigter Geschäftsführer: Joachim Richter  
Domizil: Vieristrasse 1, 8603 Schwerzenbach, Schweiz  
Gerichtsstand: Zürich  
Publikationsorgan: SHAB

---

## Datenschutz (DSGVO)

Diese Website speichert keine personenbezogenen Daten ohne Ihre ausdrückliche Zustimmung. Es werden **keine Cookies oder externen Tracker** verwendet.

**IP-Adressen** können zu Debugging-Zwecken im Server-Log gespeichert werden. Diese Logs werden **einmal pro Monat gelöscht** und nicht an Dritte weitergegeben oder ausgewertet.

Die Kontaktaufnahme per E-Mail erfolgt freiwillig. Die übermittelten Daten werden nur zur Bearbeitung Ihrer Anfrage verwendet und nicht an Dritte weitergegeben.

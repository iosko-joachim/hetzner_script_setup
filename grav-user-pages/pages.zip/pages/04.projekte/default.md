---
title: Projekte & Erfahrungen
menu: Projekte
slug: projekte
---

## Projekt-Highlights

**Witricity Schweiz (2024)**  
Entwicklung von Testsystemen für EV-Ladekomponenten, Python-GUI, DMA-Datenerfassung.

**Proregia AG (2020–2024)**  
OTA-System mit Backend, Kryptographie, BLE-Sniffering und Apple-Watch-Prototyp.

**bbv Software Services (2016–2020)**  
Java/DB2-Migration für AHV-Plattform, Security-Komponenten mit Spring Boot.
